from django.shortcuts import render
from .models import Destination


# Create your views here.

# def index(request):
#     return render(request, 'index.html')


# def index(request):
#     return render(request, 'index.html', {'price': 700})

def index(request):
    dests = Destination.objects.all()

    return render(request, 'index.html', {'dests': dests})

    # dest1 = Destination()
    # dest1.name = 'Mumba'
    # dest1.desc = 'The City That Never Sleeps! -said by- Luke'
    # dest1.img = 'destination_1.jpg'
    # dest1.price = 700
    # dest1.offer = False
    #
    # dest2 = Destination()
    # dest2.name = 'Hyderabad'
    # dest2.desc = 'First Biryani, Then Sherwani'
    # dest2.img = 'destination_2.jpg'
    # dest2.price = 800
    # dest2.offer = True
    #
    # dest3 = Destination()
    # dest3.name = 'Bengaluru'
    # dest3.desc = 'Beautiful City'
    # dest3.img = 'destination_3.jpg'
    # dest3.price = 900
    # dest3.offer = False
    #
    # dest4 = Destination()
    # dest4.price = 1000
    #
    # dest5 = Destination()
    # dest5.price = 1100
    #
    # dest6 = Destination()
    # dest6.price = 1200
    #
    # dests = [dest1, dest2, dest3]

    # return render(request,
    #               'index.html',
    #               {
    #                   'dest1': dest1,
    #                   'dest2': dest2,
    #                   'dest3': dest3,
    #                   'dest4': dest4,
    #                   'dest5': dest5,
    #                   'dest6': dest6,
    #               },
    # )

    # return render(request,
    #               'index.html',
    #               {
    #                   'dests': dests,
    #               },
    #               )
