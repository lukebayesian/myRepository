# -*- coding: utf-8 -*-
from django.urls import path
from . import views

urlpatterns = [
    path('register', views.register, name='register'),
    # path('travello', views.index, name='index'),
    # path('add', views.add, name='add'),
]
