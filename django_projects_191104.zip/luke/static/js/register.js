/* JS Document */

/******************************
[Table of Contents]
1. Vars and Inits
2. Validations
******************************/

// 1. Vars and Inits
$(document).ready(function()
{
    alert('Document Load');
    $('#btn_submit_register').on("click", function(e) {
        var thisFormData = $('#register_form').serialize();
        alert(thisFormData);
        console.log($(this).val());
        e.preventDefault
        // $('#btn_submit_register').submit();
    });
});